package com.codeclan.restaurantbookingserver.restaurantserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantserverApplication.class, args);
	}

}

